alert("Hello class");
console.log("Dia chuvoso");
