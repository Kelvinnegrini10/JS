function alterarCorDeFundo(){
    document.body.style.backgroundColor = "#48D1CC";
}

const botao = document.getElementById("meuBotao");
botao.addEventListener("click", alterarCorDeFundo);