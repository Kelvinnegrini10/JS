function destacarElemento() {
    let mae = document.querySelector("#family li ul li ul li");
    if (mae) {
        mae.classList.toggle("destaque");
    }
}
