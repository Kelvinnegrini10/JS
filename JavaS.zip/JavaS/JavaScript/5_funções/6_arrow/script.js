let consoleTeste = () => {
    console.log("Olá turma");
    
};

consoleTeste();

let soma = (a,b) => {
    return a + b ;
};
console.log(soma(14,15));
