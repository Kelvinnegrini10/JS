const multiplicacaoPorDois = (num1) => {
    return num1 * 2;

 

};
console.log(multiplicacaoPorDois(10));

