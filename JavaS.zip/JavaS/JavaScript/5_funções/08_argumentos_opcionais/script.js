function saudacao(nome, idade){
    if(idade === undefined){
        console.log("Olá" + turma);
    }else{
        console.log("Olá" + " Você tem " + idade + " anos ");
        
        
    }
}

saudacao("Kelvin", 17)
