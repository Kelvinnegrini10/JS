function fibonacci(n) {
    if (n <= 0) {
        console.log("Sequência inválida");
        return;
    }

    let a = 0, b = 1, c;
    let resultado = [];

    for (let i = 0; i < n; i++) {
        resultado.push(a);
        c = a + b;
        a = b;
        b = c;
    }

    console.log(resultado.join(" "));
}

// Exemplo de uso:
let numero = parseInt(prompt("Digite o número de termos da sequência de Fibonacci:"));
fibonacci(numero);
