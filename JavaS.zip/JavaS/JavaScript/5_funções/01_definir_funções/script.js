function imprimirConsole(){
    console.log("Olá Galera!!");
    
}
imprimirConsole();

function imprimirNumero(num){
    console.log("numero: " + num);
    
}
    imprimirNumero(3);
    imprimirNumero(7);
    imprimirNumero(9);

    function numeroAleatorio() {
        let numero = Math.random() * (100 - 10) + 10; // Gera um número entre 10 e 100
        console.log("Número Aleatório Arredondado: " + Math.round(numero));
    }
    
    numeroAleatorio();
    
    