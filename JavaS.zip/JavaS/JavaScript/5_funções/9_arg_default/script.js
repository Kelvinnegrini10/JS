function potencial(base, expo=2){
    return Math.pow(base,expo);

}
console.log(potencial(10));
console.log(potencial(10,3));


