//Multiplicação entre 3 numeros

function multiplicarNumero(numero1, numero2, numero3){
    console.log('Multiplicação: ' + (numero1 * numero2 * numero3));   
}

multiplicarNumero(7, 7, 7)



//Condições para dirigir
function CondicoesDirigir(idade, cnh){
    if (idade >= 18 && cnh == true) {
        console.log('Poder Dirigir!');
    } else {
        console.log('NÃO pode dirigir!');
    }
}
podeDirigir(55, false)