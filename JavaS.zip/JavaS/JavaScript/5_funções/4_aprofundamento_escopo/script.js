let x = 10;// 10
if (x > 5){
    let x = 20;// 20
    x++
    console.log(x);// 21
}
console.log(x); // 10
