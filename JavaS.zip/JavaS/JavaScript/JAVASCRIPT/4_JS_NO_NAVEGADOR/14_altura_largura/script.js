let elemento = document.querySelector('titulo-principal');
console.log('largura: ' + elemento.offsetWidht);
console.log('largura: ' + elemento.offsetHeigt);


console.log('largura2: ' + elemento.offsetWidht);
console.log('largura2: ' + elemento.offsetHeigt);

