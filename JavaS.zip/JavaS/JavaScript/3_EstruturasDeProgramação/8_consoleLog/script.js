let idade = 17
let nome = 'Kelvin'
console.log(nome);
console.log(idade);
console.log((`O meu nome é ${nome}, e tenho ${idade} anos`));

















