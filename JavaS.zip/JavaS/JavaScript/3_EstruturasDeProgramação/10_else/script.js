let velocidade = 70;
if (velocidade <= 80){
    console.log("não foi multado");
}else{
    console.log("foi multado");
    
}
    













