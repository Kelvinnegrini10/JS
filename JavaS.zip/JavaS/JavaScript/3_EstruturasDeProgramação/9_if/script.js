let idade = 18;
if(idade == 18)
{
    console.log("A idade é 18");
}
if(idade >25){
    console.log("Idade maior que 25");
}
let nome = "Kelvin"

if(nome == "Kelvin" && idade >18){
    console.log("liberado!");
}


let passaporte = false;
if(nome == "Kelvin" && idade > 30 || passaporte == true){
    console.log("Liberado 2!");
    
}












