console.log(`o resultado da soma é ${2+3}`);
console.log(`o resultado da subtração é ${20-10}`);
console.log(`o resultado da multiplicação é ${50*5}`);
console.log(`o resultado da divisão é ${50/2}`);
console.log(`o resultado do resto é ${20%2}`);

console.log(typeof '123'+ 12);
console.log(2 == 2 && 2);// o == aprsenta igualdade de numeros
console.log('3' === 3);// o === analisa toda a estrutura do numero ou da string e não somente a igualdade
console.log('Kelvin' == 'Kelvin' || true );
console.log(!(!(true && true)));





