console.log(5 > 3 && 3 == 2);//F
console.log(3 == 3 && 'Lucas' == 'Lucas');// V
console.log('Felipe' == 'João' || false);
console.log(!(!(true && true))); //V
console.log(true && false);//F
console.log(false || false);//V









