function consultarCEP() {
    const cep = document.getElementById("cep").value;
    const url = `https://viacep.com.br/ws/${cep}/json`;
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro na requisição");
            }
            return response.json();
        })
        .then(data => exibirResultado(data))
        .catch(error => {
            console.error("Ocorreu um erro:", error);
            document.getElementById("resultado").innerHTML = "Erro ao consultar o CEP";
        });
}

function exibirResultado(data) { 
    const resultadoDiv = document.getElementById("resultado");
    if (data.erro) {
        resultadoDiv.innerHTML = "CEP não encontrado";
    } else {
        const endereco = `
            <p><strong>CEP:</strong> ${data.cep}</p>
            <p><strong>Logradouro:</strong> ${data.logradouro}</p>
            <p><strong>Bairro:</strong> ${data.bairro}</p>
            <p><strong>Cidade:</strong> ${data.localidade}</p>
            <p><strong>Estado:</strong> ${data.uf}</p>
        `;
        resultadoDiv.innerHTML = endereco;
    }
}